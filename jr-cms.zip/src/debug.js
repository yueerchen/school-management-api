const a = 1;
const b = 2;
debugger;
console.log(a + b);
